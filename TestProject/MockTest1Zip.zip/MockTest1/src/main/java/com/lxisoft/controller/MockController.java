package com.lxisoft.controller;

public class MockController {

}
